const express = require("express");
const bodyParser = require("body-parser");
const axios = require("axios");
require("dotenv").config();

const app = express();
const PORT = 3300;

// const huggingFaceKey = process.env.HUGGING_FACE_API_KEY;

// Middleware
app.use(bodyParser.json());

// Endpoint to generate quiz questions
app.post("/generate-quiz", async (req, res) => {
  const { paragraph, numQuestions } = req.body;

  if (!paragraph || !numQuestions) {
    return res.status(400).json({
      error: "Please provide both 'paragraph' and 'numQuestions'.",
    });
  }

  try {
    const quizQuestions = [];

    // Generate the specified number of questions
    for (let i = 0; i < numQuestions; i++) {
      const response = await axios.post(
        "https://api-inference.huggingface.co/models/distilgpt2",
        {
          inputs: `Create a quiz question with 4 options based on: ${paragraph}`,
        },
        {
          headers: {
            'Authorization': `Bearer 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`,
          },
        }
      );

      // Extract the generated text from the response
      const generatedText = response.data.generated_text || "";

      // Parse the response to extract a question and four options
      const questionMatch = generatedText.match(/^(.*?\?)\s*(.*)$/);
      const optionsMatch = questionMatch
        ? questionMatch[2].split(/\s*\d\.\s*/).slice(1)
        : [];

      // Structure the question
      if (questionMatch && optionsMatch.length >= 4) {
        quizQuestions.push({
          question: questionMatch[1],
          options: optionsMatch.slice(0, 4), // Ensure only 4 options
        });
      }
    }

    // Send the generated questions as the response
    res.status(200).json({
      quizQuestions,
    });
  } catch (error) {
    console.error("Error generating quiz:", error.response?.data || error.message);
    res.status(500).json({
      error: "Failed to generate quiz questions. Please try again later.",
    });
  }
});

// Root endpoint
app.get("/", (req, res) => {
  res.send("Quiz Generator is running! Use POST /generate-quiz.");
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
