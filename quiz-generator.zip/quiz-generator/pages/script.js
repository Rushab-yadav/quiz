let currentQuestion = 0;
let score = 0;
const questions = [
    {
        question: "What is the capital of France?",
        options: ["Berlin", "Madrid", "Paris", "Rome"],
        answer: 2
    },
    {
        question: "What is 2 + 2?",
        options: ["3", "4", "5", "6"],
        answer: 1
    },
    {
        question: "What is the largest planet in our solar system?",
        options: ["Earth", "Mars", "Jupiter", "Saturn"],
        answer: 2
    },
    {
        question: "Who wrote 'Hamlet'?",
        options: ["Shakespeare", "Dickens", "Hemingway", "Austen"],
        answer: 0
    },
    {
        question: "Which language is primarily used for web development?",
        options: ["Python", "Java", "C++", "JavaScript"],
        answer: 3
    },
    {
        question: "What is the tallest mountain on Earth?",
        options: ["K2", "Mount Everest", "Kangchenjunga", "Lhotse"],
        answer: 1
    },
    {
        question: "Which country is known as the Land of the Rising Sun?",
        options: ["China", "Japan", "India", "South Korea"],
        answer: 1
    },
    {
        question: "What is the largest ocean on Earth?",
        options: ["Atlantic", "Indian", "Arctic", "Pacific"],
        answer: 3
    },
    {
        question: "What is the smallest country in the world?",
        options: ["Monaco", "Vatican City", "Nauru", "San Marino"],
        answer: 1
    },
    {
        question: "Who discovered gravity?",
        options: ["Einstein", "Galileo", "Newton", "Kepler"],
        answer: 2
    },
    {
        question: "What is the hardest natural substance?",
        options: ["Gold", "Iron", "Diamond", "Platinum"],
        answer: 2
    },
    {
        question: "What is the speed of light?",
        options: ["300,000 km/s", "150,000 km/s", "500,000 km/s", "1,000,000 km/s"],
        answer: 0
    },
    {
        question: "Who painted the Mona Lisa?",
        options: ["Van Gogh", "Picasso", "Da Vinci", "Michelangelo"],
        answer: 2
    },
    {
        question: "What is the square root of 64?",
        options: ["6", "8", "10", "12"],
        answer: 1
    },
    {
        question: "Which planet is known as the Red Planet?",
        options: ["Venus", "Mars", "Saturn", "Uranus"],
        answer: 1
    }
];

function displayQuestion() {
    const question = questions[currentQuestion];
    document.getElementById("question").textContent = question.question;
    const buttons = document.querySelectorAll(".option-btn");
    buttons.forEach((button, index) => {
        button.textContent = question.options[index];
    });
}

function selectOption(index) {
    const question = questions[currentQuestion];
    if (index === question.answer) {
        score++;
    }
    document.getElementById("score").textContent = "Score: " + score;
    document.getElementById("next-btn").disabled = false;
}

function nextQuestion() {
    currentQuestion++;
    if (currentQuestion < questions.length) {
        displayQuestion();
        document.getElementById("next-btn").disabled = true;
    } else {
        document.getElementById("question").textContent = "Quiz Completed!";
        document.getElementById("options-container").style.display = "none";
        document.getElementById("next-btn").style.display = "none";
    }
}

displayQuestion();
